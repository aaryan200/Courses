#include "types.h"
#include "stat.h"
#include "user.h"

/*
User code makes a system call to print the page table entries
Example:
Entry number: 0, Virtual address: 0x00000000, Physical address: 0xdee0000
Entry number: 1, Virtual address: 0x00001000, Physical address: 0xde20000
*/

// Uncomment the following line to see the page table entries when a global array is declared
// int arr[10000];

int main(void)
{
    // Uncomment the following line to see the page table entries when a local array is declared
    // int arr[10000];
    // arr[0] = 0;
    // for (int i=0;i<10000;i++) arr[i] += 0;
    pgtPrint();
    exit();
}