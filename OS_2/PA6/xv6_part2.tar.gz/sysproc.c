#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int sys_fork(void)
{
  return fork();
}

int sys_exit(void)
{
  exit();
  return 0; // not reached
}

int sys_wait(void)
{
  return wait();
}

int sys_kill(void)
{
  int pid;

  if (argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int sys_getpid(void)
{
  return myproc()->pid;
}

int sys_sbrk(void)
{
  int addr;
  int n;

  if (argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if (growproc(n) < 0)
    return -1;
  return addr;
}

int sys_sleep(void)
{
  int n;
  uint ticks0;

  if (argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while (ticks - ticks0 < n)
  {
    if (myproc()->killed)
    {
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// mydate system call
int sys_mydate(void)
{
  struct rtcdate *r;
  if (argptr(0, (void *)&r, sizeof(*r)) < 0)
    return -1;
  cmostime(r);
  return 0;
}

// pgtPrint system call
int sys_pgtPrint(void)
{
  struct proc *curproc = myproc();

  // Page directory of current process
  pde_t *pgdirectory = curproc->pgdir;
  // Traverse page directory to get page tables
  for (int i = 0; i < NPDENTRIES; i++)
  {
    // Check if it is a valid page table
    if (pgdirectory[i] & PTE_P)
    {
      pte_t *pgtable = (pte_t *)P2V(PTE_ADDR(pgdirectory[i]));
      for (int j = 0; j < NPTENTRIES; j++)
      {
        // Check if it is a valid page and is allowed access in user mode
        if ((pgtable[j] & PTE_P) && (pgtable[j] & PTE_U))
        {
          uint pa = PTE_ADDR(pgtable[j]); // Physical address
          uint va = PGADDR(i, j, 0);      // Virtual address
          // write bit
          if (pgtable[j] & PTE_W)
            cprintf("pgdir entry num: %d, Pgt entry num: %d, Virtual address: %x, Physical address: %p, W-bit: 1\n", i, j, va, pa);
          else
            cprintf("pgdir entry num: %d, Pgt entry num: %d, Virtual address: %x, Physical address: %p, W-bit: 0\n", i, j, va, pa);
        }
      }
    }
  }
  return 0;
}