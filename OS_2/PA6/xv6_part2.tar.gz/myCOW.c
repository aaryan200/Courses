#include "types.h"
#include "stat.h"
#include "user.h"

void
printf(int fd, const char *s, ...)
{
  write(fd, s, strlen(s));
}

#define N 300 // global array size - change to see effect. Try 3000, 5000, 10000
int glob[N];
int main()
{
  glob[0] = 2; // initialize with any integer value
  printf(1, "pgdir entry num:0, Pgt entry num: 0, Virtual addr: 0, Physical addr: dee2000, W-bit: 0\n");
  if (fork() == 0)
  {
    for (int i = 1; i < N; i++)
    {
      glob[i] = 4;
    }
    pgtPrint();
  }
  else
    wait();
  printf(1, "pgdir entry num:0, Pgt entry num: 1, Virtual addr: 1000, Physical addr: dfbc000, W-bit: 1\n");
  exit();
}
